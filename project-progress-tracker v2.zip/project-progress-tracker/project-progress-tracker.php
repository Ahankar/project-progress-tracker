<?php
/*
Plugin Name: Project Progress Tracker
Description: پلاگینی برای پیگیری و نمایش پیشرفت پروژه‌های کارفرماها
Version: 1.0
Author: Your Name
*/

require_once plugin_dir_path(__FILE__) . 'admin-page.php';
require_once plugin_dir_path(__FILE__) . 'shortcode.php';

// ایجاد جدول پایگاه داده برای ذخیره اطلاعات پروژه‌ها
function ppt_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'project_progress';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        client_id bigint(20) NOT NULL,
        project_name varchar(255) NOT NULL,
        progress text NOT NULL,
        task_list text NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

register_activation_hook(__FILE__, 'ppt_create_table');
?>

