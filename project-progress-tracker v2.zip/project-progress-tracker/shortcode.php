<?php
// نمایش پیشرفت پروژه در پنل کاربری هر کارفرما
function ppt_display_project_progress($atts) {
    if (is_user_logged_in()) {
        global $wpdb;
        $current_user = wp_get_current_user();
        $table_name = $wpdb->prefix . 'project_progress';
        $client_id = $current_user->ID;

        $projects = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE client_id = %d", $client_id));

        if (!empty($projects)) {
            echo '<table class="wp-list-table widefat fixed striped">';
            echo '<thead><tr><th>نام پروژه</th><th>پیشرفت</th><th>وظایف</th></tr></thead>';
            echo '<tbody>';
            foreach ($projects as $project) {
                echo '<tr>';
                echo '<td>' . esc_html($project->project_name) . '</td>';
                echo '<td>' . esc_html($project->progress) . '</td>';
                echo '<td>' . esc_html($project->task_list) . '</td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
        } else {
            echo '<p>هیچ پروژه‌ای یافت نشد.</p>';
        }
    } else {
        echo '<p>برای مشاهده اطلاعات باید وارد شوید.</p>';
    }
}

add_shortcode('project_progress', 'ppt_display_project_progress');

?>
