<?php
// افزودن منوی مدیریت برای ثبت پروژه‌ها
function ppt_add_admin_menu() {
    add_menu_page('پیگیری پیشرفت پروژه', 'پیشرفت پروژه', 'manage_options', 'project-progress-tracker', 'ppt_admin_page');
}

add_action('admin_menu', 'ppt_add_admin_menu');

function ppt_admin_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'project_progress';

    if (isset($_POST['submit'])) {
        $client_id = intval($_POST['client_id']);
        $project_name = sanitize_text_field($_POST['project_name']);
        $progress = sanitize_textarea_field($_POST['progress']);
        $task_list = sanitize_textarea_field($_POST['task_list']);

        $wpdb->insert(
            $table_name,
            array(
                'client_id' => $client_id,
                'project_name' => $project_name,
                'progress' => $progress,
                'task_list' => $task_list
            )
        );
        echo '<div class="updated"><p>پروژه با موفقیت ثبت شد!</p></div>';
    }

    if (isset($_POST['update'])) {
        $id = intval($_POST['id']);
        $project_name = sanitize_text_field($_POST['project_name']);
        $progress = sanitize_textarea_field($_POST['progress']);
        $task_list = sanitize_textarea_field($_POST['task_list']);

        $wpdb->update(
            $table_name,
            array(
                'project_name' => $project_name,
                'progress' => $progress,
                'task_list' => $task_list
            ),
            array('id' => $id)
        );
        echo '<div class="updated"><p>پروژه با موفقیت به‌روزرسانی شد!</p></div>';
    }

    if (isset($_POST['delete'])) {
        $id = intval($_POST['id']);

        $wpdb->delete(
            $table_name,
            array('id' => $id)
        );
        echo '<div class="updated"><p>پروژه با موفقیت حذف شد!</p></div>';
    }

    $projects = $wpdb->get_results("SELECT * FROM $table_name");

    ?>
    <div class="wrap">
        <h2>پیگیری پیشرفت پروژه</h2>
        <form method="post" action="">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">شناسه کارفرما</th>
                    <td><input type="number" name="client_id" required /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">نام پروژه</th>
                    <td><input type="text" name="project_name" required /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">پیشرفت پروژه</th>
                    <td><textarea name="progress" required></textarea></td>
                </tr>
                <tr valign="top">
                    <th scope="row">لیست وظایف</th>
                    <td><textarea name="task_list" required></textarea></td>
                </tr>
            </table>
            <input type="submit" name="submit" value="افزودن پروژه" class="button button-primary" />
        </form>

        <h2>مدیریت پروژه‌ها</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th scope="col">شناسه</th>
                    <th scope="col">نام پروژه</th>
                    <th scope="col">پیشرفت</th>
                    <th scope="col">وظایف</th>
                    <th scope="col">عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($projects as $project) : ?>
                <tr>
                    <td><?php echo esc_html($project->id); ?></td>
                    <td><?php echo esc_html($project->project_name); ?></td>
                    <td><?php echo esc_html($project->progress); ?></td>
                    <td><?php echo esc_html($project->task_list); ?></td>
                    <td>
                        <form method="post" action="" style="display: inline;">
                            <input type="hidden" name="id" value="<?php echo esc_attr($project->id); ?>">
                            <input type="text" name="project_name" value="<?php echo esc_attr($project->project_name); ?>" required>
                            <textarea name="progress" required><?php echo esc_textarea($project->progress); ?></textarea>
                            <textarea name="task_list" required><?php echo esc_textarea($project->task_list); ?></textarea>
                            <input type="submit" name="update" value="به‌روزرسانی" class="button button-primary" />
                        </form>
                        <form method="post" action="" style="display: inline;">
                            <input type="hidden" name="id" value="<?php echo esc_attr($project->id); ?>">
                            <input type="submit" name="delete" value="حذف" class="button button-secondary" />
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

?>
